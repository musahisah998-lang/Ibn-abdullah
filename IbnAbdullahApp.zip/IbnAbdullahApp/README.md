# Ibn Abdullah Littahfizul Qur'an Wal Islamiyya — Admission App

Native Android app (Kotlin + Jetpack Compose + Room + Firebase) for managing student
admissions: offline-first with SQLite (Room), optional online sync to Firebase.

Motto: **"Al-Ilmu Wat-Tarbiyyah"**

## Features

1. Welcome screen with school logo & motto
2. Student Application Form (full bio-data, photo, birth certificate upload)
3. Auto-generated unique Application Number (e.g. `IALQ/2026/0001`)
4. Save-as-draft and Submit
5. Admin Dashboard — view, approve/reject, search, print applications
6. Admission Status Checker (by Application Number)
7. Notification system for status updates (local notifications + FCM-ready)
8. Islamic green & white Material 3 theme
9. Responsive layouts for phones
10. Offline-first via Room (SQLite) + optional Firebase Firestore sync
11. Secure admin login (hashed credentials, Firebase Auth-ready)
12. Export applicant data to PDF and Excel (CSV/XLSX)
13. English + Hausa language support (`values/` and `values-ha/`)
14. **Lesson materials** — Admins and Teachers can upload lesson files (PDF, images, docs) tagged to a class/subject. Approved students (parents) can log in with their **Application Number + parent phone number** — no separate signup — and see only the lessons matching their class.

## Lesson Feature — How It Works

- **Admin** uploads lessons directly from the Admin Dashboard → "Upload Lesson".
- **Teacher accounts** are created by the admin (there is a `LessonRepository.registerTeacher()` method ready to use — wiring up an "Add Teacher" screen in the admin dashboard is the one piece left to build; for now you can seed a teacher account the same way the default admin account is seeded in `AppDatabase.kt`).
- **Students/Parents** log in on the Welcome screen → "Student Login", using the Application Number and parent phone number from their (approved) admission application. They then see only lessons tagged with their `classApplyingFor`.
- Uploaded files are opened via an `ACTION_VIEW` intent (whatever PDF/image viewer the phone already has installed).

⚠️ **Known gap to close before real use:** File `Uri`s from the system picker (`ActivityResultContracts.GetContent`) are only guaranteed readable for the current app session unless you call `contentResolver.takePersistableUriPermission()` on selection. Add that call in `ApplicationFormScreen.kt` and `UploadLessonScreen.kt` before shipping, or files may fail to open after the device restarts.


## Project Structure

```
IbnAbdullahApp/
├── build.gradle                        # Project-level Gradle config
├── settings.gradle
├── app/
│   ├── build.gradle                    # App-level Gradle config & dependencies
│   └── src/main/
│       ├── AndroidManifest.xml
│       ├── java/com/ibnabdullah/tahfizul/
│       │   ├── MainActivity.kt         # Nav host / entry point
│       │   ├── data/
│       │   │   ├── Applicant.kt        # Room entity
│       │   │   ├── Admin.kt            # Room entity
│       │   │   ├── ApplicantDao.kt     # Room DAO
│       │   │   ├── AppDatabase.kt      # Room database
│       │   │   └── ApplicantRepository.kt
│       │   ├── viewmodel/
│       │   │   └── ApplicantViewModel.kt
│       │   ├── ui/
│       │   │   ├── theme/              # Color.kt, Theme.kt, Type.kt
│       │   │   └── screens/
│       │   │       ├── WelcomeScreen.kt
│       │   │       ├── ApplicationFormScreen.kt
│       │   │       ├── AdminLoginScreen.kt
│       │   │       ├── AdminDashboardScreen.kt
│       │   │       └── StatusCheckerScreen.kt
│       │   ├── utils/
│       │   │   ├── ApplicationNumberGenerator.kt
│       │   │   ├── PdfExporter.kt
│       │   │   ├── ExcelExporter.kt
│       │   │   └── NotificationHelper.kt
│       │   └── firebase/
│       │       └── FirebaseSyncManager.kt
│       └── res/
│           ├── values/strings.xml      # English
│           ├── values-ha/strings.xml   # Hausa
│           ├── values/colors.xml       # Green & white Islamic theme
│           └── drawable/               # logo placeholder, icons
```

## Building an APK Without a Laptop (GitHub Actions)

This project includes a ready-made cloud build config at
`.github/workflows/build.yml`. It lets GitHub's servers compile the app for
you — you only need a phone and a free GitHub account.

1. Create a free account at github.com (if you don't have one).
2. Create a new **public** repository (e.g. `ibn-abdullah-app`).
3. Upload every file/folder from this project into that repository, keeping
   the folder structure intact (including the hidden `.github` folder).
4. Go to the repository's **Actions** tab. A workflow called "Build APK"
   should start automatically. If it doesn't, click "Build APK" → "Run workflow".
5. Wait a few minutes for it to finish (green checkmark = success).
6. Click into the finished run → scroll to **Artifacts** →
   download `ibn-abdullah-admissions-debug-apk`. This is a `.zip` containing
   the installable `app-debug.apk`.
7. On your Android phone: unzip it, tap the `.apk` file, and allow
   "install from unknown sources" if prompted. The app installs like any
   other app.

Note: this produces a **debug build**, fine for testing. For a production
release to distribute widely, you'd generate a signed release APK/AAB
(a later step once you're happy with the app).

## Setup Instructions

1. Open the `IbnAbdullahApp` folder in **Android Studio (Koala+)**.
2. Let Gradle sync — it will pull Room, Compose, Firebase BOM, and Apache POI.
3. Replace `app/src/main/res/drawable/school_logo.xml` with the real school logo.
4. To enable Firebase sync:
   - Create a Firebase project, add an Android app with package `com.ibnabdullah.tahfizul`.
   - Download `google-services.json` into `app/`.
   - Uncomment the `google-services` plugin lines in the two `build.gradle` files.
5. Default admin seed account (change immediately): `admin / Admin@12345` (stored as a
   SHA-256 hash in `AppDatabase.kt`'s `onCreate` callback — replace before production use).
6. Build & run on a device/emulator (min SDK 24, target SDK 34).

## Data Flow

- All writes go to **Room** first (offline-first) → app is fully usable without internet.
- `FirebaseSyncManager` listens for connectivity and pushes/pulls unsynced records to
  **Cloud Firestore** (`applicants` collection) when online. Conflict rule: last-write-wins
  based on `updatedAt` timestamp.
- PDF export uses Android's built-in `PdfDocument` API (no extra dependency).
- Excel export uses **Apache POI** (`.xlsx`) — falls back to CSV if POI isn't desired.

## Security Notes

- Admin passwords are hashed (SHA-256 + salt) before storage — never stored in plain text.
- For production, swap the local admin table for **Firebase Authentication** (email/password
  or phone) — `FirebaseSyncManager` already has a stub method `signInAdmin()` for this.
- Uploaded photos/birth certificates are stored in app-private internal storage and referenced
  by file path in Room; when synced, they upload to Firebase Storage and the Firestore record
  stores the download URL instead.

## Extending Language Support

Add more `values-xx/strings.xml` folders (e.g. `values-ar` for Arabic) following the same
keys as `values/strings.xml`. The app follows system locale automatically; a manual toggle
is also provided in Settings via `AppCompatDelegate.setApplicationLocales()`.
