package com.ibnabdullah.tahfizul.utils

import android.content.Context
import android.os.Environment
import com.ibnabdullah.tahfizul.data.Applicant
import org.apache.poi.ss.usermode.WorkbookFactory
import org.apache.poi.xssf.usermodel.XSSFWorkbook
import java.io.File
import java.io.FileOutputStream

/** Exports the full applicant list to a .xlsx workbook (Apache POI). */
object ExcelExporter {

    private val HEADERS = listOf(
        "Application Number", "Full Name", "Date of Birth", "Gender",
        "State of Origin", "Local Government", "Home Address",
        "Parent/Guardian", "Parent Phone", "Email", "Previous School",
        "Class Applying For", "Health Information", "Status", "Submitted On"
    )

    fun exportAll(context: Context, applicants: List<Applicant>): File {
        val workbook = XSSFWorkbook()
        val sheet = workbook.createSheet("Applicants")

        val headerRow = sheet.createRow(0)
        HEADERS.forEachIndexed { i, h -> headerRow.createCell(i).setCellValue(h) }

        applicants.forEachIndexed { rowIndex, a ->
            val row = sheet.createRow(rowIndex + 1)
            val values = listOf(
                a.applicationNumber, a.fullName, a.dateOfBirth, a.gender,
                a.stateOfOrigin, a.localGovernment, a.homeAddress,
                a.parentGuardianName, a.parentPhoneNumber, a.email ?: "",
                a.previousSchool, a.classApplyingFor, a.healthInformation,
                a.status.name,
                java.text.SimpleDateFormat("yyyy-MM-dd HH:mm", java.util.Locale.US)
                    .format(java.util.Date(a.createdAt))
            )
            values.forEachIndexed { colIndex, v -> row.createCell(colIndex).setCellValue(v) }
        }

        for (i in HEADERS.indices) sheet.autoSizeColumn(i)

        val outDir = context.getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS)
            ?: context.filesDir
        val outFile = File(outDir, "applicants_export.xlsx")
        FileOutputStream(outFile).use { workbook.write(it) }
        workbook.close()
        return outFile
    }
}
