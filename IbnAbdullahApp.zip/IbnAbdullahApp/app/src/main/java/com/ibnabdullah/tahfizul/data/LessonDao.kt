package com.ibnabdullah.tahfizul.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface TeacherDao {
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insert(teacher: Teacher): Long

    @Query("SELECT * FROM teachers WHERE username = :username LIMIT 1")
    suspend fun getByUsername(username: String): Teacher?

    @Query("SELECT * FROM teachers ORDER BY fullName ASC")
    fun getAll(): Flow<List<Teacher>>

    @Delete
    suspend fun delete(teacher: Teacher)
}

@Dao
interface LessonDao {
    @Insert
    suspend fun insert(lesson: Lesson): Long

    @Query("SELECT * FROM lessons ORDER BY createdAt DESC")
    fun getAll(): Flow<List<Lesson>>

    @Query("SELECT * FROM lessons WHERE classOrSubject = :classOrSubject ORDER BY createdAt DESC")
    fun getByClass(classOrSubject: String): Flow<List<Lesson>>

    @Delete
    suspend fun delete(lesson: Lesson)
}
