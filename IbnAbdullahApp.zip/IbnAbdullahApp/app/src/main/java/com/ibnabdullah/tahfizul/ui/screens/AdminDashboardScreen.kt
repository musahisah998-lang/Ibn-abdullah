package com.ibnabdullah.tahfizul.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.ibnabdullah.tahfizul.R
import com.ibnabdullah.tahfizul.data.Applicant
import com.ibnabdullah.tahfizul.data.ApplicationStatus

@Composable
fun AdminDashboardScreen(
    applicants: List<Applicant>,
    onSearch: (String) -> Unit,
    onFilter: (ApplicationStatus?) -> Unit,
    onApprove: (Applicant) -> Unit,
    onReject: (Applicant, String) -> Unit,
    onPrint: (Applicant) -> Unit,
    onExportPdfAll: () -> Unit,
    onExportExcel: () -> Unit,
    onUploadLesson: () -> Unit,
    onLogout: () -> Unit
) {
    var query by remember { mutableStateOf("") }
    var rejectDialogFor by remember { mutableStateOf<Applicant?>(null) }
    var rejectReason by remember { mutableStateOf("") }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(stringResource(R.string.admin_dashboard)) },
                actions = {
                    TextButton(onClick = onLogout) { Text(stringResource(R.string.logout)) }
                }
            )
        }
    ) { padding ->
        Column(modifier = Modifier.padding(padding).padding(12.dp)) {

            OutlinedTextField(
                value = query,
                onValueChange = { query = it; onSearch(it) },
                label = { Text(stringResource(R.string.search_applicants)) },
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(8.dp))

            Row(modifier = Modifier.fillMaxWidth()) {
                FilterChip("All") { onFilter(null) }
                FilterChip("Submitted") { onFilter(ApplicationStatus.SUBMITTED) }
                FilterChip("Approved") { onFilter(ApplicationStatus.APPROVED) }
                FilterChip("Rejected") { onFilter(ApplicationStatus.REJECTED) }
            }
            Spacer(Modifier.height(8.dp))

            Row(modifier = Modifier.fillMaxWidth()) {
                OutlinedButton(onClick = onExportPdfAll, modifier = Modifier.weight(1f)) {
                    Text(stringResource(R.string.export_pdf))
                }
                Spacer(Modifier.width(8.dp))
                OutlinedButton(onClick = onExportExcel, modifier = Modifier.weight(1f)) {
                    Text(stringResource(R.string.export_excel))
                }
            }
            Spacer(Modifier.height(8.dp))
            OutlinedButton(onClick = onUploadLesson, modifier = Modifier.fillMaxWidth()) {
                Text(stringResource(R.string.upload_lesson))
            }
            Spacer(Modifier.height(8.dp))

            LazyColumn {
                items(applicants) { applicant ->
                    ApplicantCard(
                        applicant = applicant,
                        onApprove = { onApprove(applicant) },
                        onReject = { rejectDialogFor = applicant },
                        onPrint = { onPrint(applicant) }
                    )
                    Spacer(Modifier.height(8.dp))
                }
            }
        }
    }

    rejectDialogFor?.let { applicant ->
        AlertDialog(
            onDismissRequest = { rejectDialogFor = null },
            title = { Text(stringResource(R.string.reject_application)) },
            text = {
                OutlinedTextField(
                    value = rejectReason,
                    onValueChange = { rejectReason = it },
                    label = { Text(stringResource(R.string.reason)) }
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    onReject(applicant, rejectReason)
                    rejectReason = ""
                    rejectDialogFor = null
                }) { Text(stringResource(R.string.confirm)) }
            },
            dismissButton = {
                TextButton(onClick = { rejectDialogFor = null }) { Text(stringResource(R.string.cancel)) }
            }
        )
    }
}

@Composable
private fun FilterChip(label: String, onClick: () -> Unit) {
    AssistChip(onClick = onClick, label = { Text(label) }, modifier = Modifier.padding(end = 6.dp))
}

@Composable
private fun ApplicantCard(
    applicant: Applicant,
    onApprove: () -> Unit,
    onReject: () -> Unit,
    onPrint: () -> Unit
) {
    ElevatedCard(modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(12.dp)) {
            Text(applicant.fullName, style = MaterialTheme.typography.titleMedium)
            Text(applicant.applicationNumber, style = MaterialTheme.typography.bodyMedium)
            Text("Class: ${applicant.classApplyingFor}  •  Status: ${applicant.status.name}",
                style = MaterialTheme.typography.bodyMedium)

            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                TextButton(onClick = onApprove) { Text(stringResource(R.string.approve)) }
                TextButton(onClick = onReject) { Text(stringResource(R.string.reject)) }
                TextButton(onClick = onPrint) { Text(stringResource(R.string.print)) }
            }
        }
    }
}
