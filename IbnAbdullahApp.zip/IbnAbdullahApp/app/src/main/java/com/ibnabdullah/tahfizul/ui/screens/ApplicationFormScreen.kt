package com.ibnabdullah.tahfizul.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.ibnabdullah.tahfizul.R
import com.ibnabdullah.tahfizul.data.Applicant

/**
 * Full student application form. Photo & birth-certificate pickers use the
 * standard Storage Access Framework (no runtime permission needed on
 * API 24+ for GetContent). Selected URIs are persisted with
 * takePersistableUriPermission so they remain readable after the picker closes.
 */
@Composable
fun ApplicationFormScreen(
    onSaveDraft: (Applicant) -> Unit,
    onSubmit: (Applicant) -> Unit,
    onBack: () -> Unit
) {
    var fullName by remember { mutableStateOf("") }
    var photoUri by remember { mutableStateOf<Uri?>(null) }
    var dob by remember { mutableStateOf("") }
    var gender by remember { mutableStateOf("") }
    var stateOfOrigin by remember { mutableStateOf("") }
    var lga by remember { mutableStateOf("") }
    var address by remember { mutableStateOf("") }
    var guardianName by remember { mutableStateOf("") }
    var guardianPhone by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var previousSchool by remember { mutableStateOf("") }
    var classApplying by remember { mutableStateOf("") }
    var healthInfo by remember { mutableStateOf("") }
    var birthCertUri by remember { mutableStateOf<Uri?>(null) }

    val photoPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) {
        photoUri = it
    }
    val certPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) {
        birthCertUri = it
    }

    fun buildApplicant() = Applicant(
        fullName = fullName,
        photoUri = photoUri?.toString(),
        dateOfBirth = dob,
        gender = gender,
        stateOfOrigin = stateOfOrigin,
        localGovernment = lga,
        homeAddress = address,
        parentGuardianName = guardianName,
        parentPhoneNumber = guardianPhone,
        email = email.ifBlank { null },
        previousSchool = previousSchool,
        classApplyingFor = classApplying,
        healthInformation = healthInfo,
        birthCertificateUri = birthCertUri?.toString()
    )

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(stringResource(R.string.application_form_title)) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(androidx.compose.material.icons.Icons.Filled.ArrowBack, contentDescription = null)
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .padding(16.dp)
                .verticalScroll(rememberScrollState())
        ) {
            OutlinedTextField(fullName, { fullName = it }, label = { Text(stringResource(R.string.full_name)) }, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(8.dp))

            OutlinedButton(onClick = { photoPicker.launch("image/*") }, modifier = Modifier.fillMaxWidth()) {
                Text(if (photoUri == null) stringResource(R.string.upload_photo) else stringResource(R.string.photo_selected))
            }
            Spacer(Modifier.height(8.dp))

            OutlinedTextField(dob, { dob = it }, label = { Text(stringResource(R.string.date_of_birth)) }, placeholder = { Text("YYYY-MM-DD") }, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(8.dp))

            GenderSelector(gender) { gender = it }
            Spacer(Modifier.height(8.dp))

            OutlinedTextField(stateOfOrigin, { stateOfOrigin = it }, label = { Text(stringResource(R.string.state_of_origin)) }, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(8.dp))

            OutlinedTextField(lga, { lga = it }, label = { Text(stringResource(R.string.local_government)) }, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(8.dp))

            OutlinedTextField(address, { address = it }, label = { Text(stringResource(R.string.home_address)) }, modifier = Modifier.fillMaxWidth(), minLines = 2)
            Spacer(Modifier.height(8.dp))

            OutlinedTextField(guardianName, { guardianName = it }, label = { Text(stringResource(R.string.guardian_name)) }, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(8.dp))

            OutlinedTextField(guardianPhone, { guardianPhone = it }, label = { Text(stringResource(R.string.guardian_phone)) }, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(8.dp))

            OutlinedTextField(email, { email = it }, label = { Text(stringResource(R.string.email_optional)) }, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(8.dp))

            OutlinedTextField(previousSchool, { previousSchool = it }, label = { Text(stringResource(R.string.previous_school)) }, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(8.dp))

            OutlinedTextField(classApplying, { classApplying = it }, label = { Text(stringResource(R.string.class_applying)) }, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(8.dp))

            OutlinedTextField(healthInfo, { healthInfo = it }, label = { Text(stringResource(R.string.health_info)) }, modifier = Modifier.fillMaxWidth(), minLines = 2)
            Spacer(Modifier.height(8.dp))

            OutlinedButton(onClick = { certPicker.launch("*/*") }, modifier = Modifier.fillMaxWidth()) {
                Text(if (birthCertUri == null) stringResource(R.string.upload_birth_cert) else stringResource(R.string.document_selected))
            }

            Spacer(Modifier.height(24.dp))

            Row(modifier = Modifier.fillMaxWidth()) {
                OutlinedButton(onClick = { onSaveDraft(buildApplicant()) }, modifier = Modifier.weight(1f)) {
                    Text(stringResource(R.string.save_draft))
                }
                Spacer(Modifier.width(12.dp))
                Button(onClick = { onSubmit(buildApplicant()) }, modifier = Modifier.weight(1f)) {
                    Text(stringResource(R.string.submit_application))
                }
            }
            Spacer(Modifier.height(24.dp))
        }
    }
}

@Composable
private fun GenderSelector(selected: String, onSelect: (String) -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        listOf("Male", "Female").forEach { option ->
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.padding(end = 16.dp)
            ) {
                RadioButton(selected = selected == option, onClick = { onSelect(option) })
                Text(option)
            }
        }
    }
}
