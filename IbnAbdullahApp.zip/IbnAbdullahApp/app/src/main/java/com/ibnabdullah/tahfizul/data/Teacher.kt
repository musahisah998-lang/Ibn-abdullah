package com.ibnabdullah.tahfizul.data

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Teacher account — separate from Admin, with narrower permissions
 * (can upload/manage lessons, but cannot approve/reject applications
 * or access the admissions dashboard).
 */
@Entity(tableName = "teachers")
data class Teacher(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val username: String,
    val passwordHash: String,
    val salt: String,
    val fullName: String = "",
    val subjectOrClass: String = "", // e.g. "Qur'an - Primary 3" for their own reference
    val createdAt: Long = System.currentTimeMillis()
)
