package com.ibnabdullah.tahfizul.data

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class ApplicationStatus { DRAFT, SUBMITTED, APPROVED, REJECTED }

/**
 * Core entity representing one student's admission application.
 * Stored locally in SQLite (Room) and optionally mirrored to Firestore
 * (see [com.ibnabdullah.tahfizul.firebase.FirebaseSyncManager]).
 */
@Entity(tableName = "applicants")
data class Applicant(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,

    // Auto-generated, human-readable unique ID e.g. IALQ/2026/0001
    val applicationNumber: String = "",

    val fullName: String = "",
    val photoUri: String? = null,               // path to saved passport photograph
    val dateOfBirth: String = "",                // ISO date yyyy-MM-dd
    val gender: String = "",                     // Male / Female
    val stateOfOrigin: String = "",
    val localGovernment: String = "",
    val homeAddress: String = "",
    val parentGuardianName: String = "",
    val parentPhoneNumber: String = "",
    val email: String? = null,                   // optional
    val previousSchool: String = "",
    val classApplyingFor: String = "",
    val healthInformation: String = "",
    val birthCertificateUri: String? = null,      // path to uploaded document

    val status: ApplicationStatus = ApplicationStatus.DRAFT,
    val rejectionReason: String? = null,

    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    val syncedToCloud: Boolean = false
)
