package com.ibnabdullah.tahfizul.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ibnabdullah.tahfizul.R
import com.ibnabdullah.tahfizul.ui.theme.IslamicGreen
import com.ibnabdullah.tahfizul.ui.theme.IslamicGreenDark
import com.ibnabdullah.tahfizul.ui.theme.PureWhite

@Composable
fun WelcomeScreen(
    onApplyClick: () -> Unit,
    onCheckStatusClick: () -> Unit,
    onAdminClick: () -> Unit,
    onTeacherClick: () -> Unit,
    onStudentClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(IslamicGreenDark, IslamicGreen))),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.padding(32.dp)
        ) {
            Surface(
                shape = CircleShape,
                color = PureWhite,
                modifier = Modifier.size(110.dp)
            ) {
                Box(contentAlignment = Alignment.Center, modifier = Modifier.fillMaxSize()) {
                    Icon(
                        imageVector = Icons.Filled.MenuBook,
                        contentDescription = stringResource(R.string.school_logo_desc),
                        tint = IslamicGreen,
                        modifier = Modifier.size(56.dp)
                    )
                }
            }

            Spacer(Modifier.height(24.dp))

            Text(
                text = stringResource(R.string.school_name),
                color = PureWhite,
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold,
                textAlign = androidx.compose.ui.text.style.TextAlign.Center
            )

            Spacer(Modifier.height(8.dp))

            Text(
                text = stringResource(R.string.school_motto),
                color = PureWhite,
                fontSize = 16.sp,
                fontStyle = FontStyle.Italic
            )

            Spacer(Modifier.height(48.dp))

            Button(
                onClick = onApplyClick,
                colors = ButtonDefaults.buttonColors(containerColor = PureWhite, contentColor = IslamicGreen),
                modifier = Modifier.fillMaxWidth()
            ) { Text(stringResource(R.string.start_application)) }

            Spacer(Modifier.height(12.dp))

            OutlinedButton(
                onClick = onCheckStatusClick,
                colors = ButtonDefaults.outlinedButtonColors(contentColor = PureWhite),
                modifier = Modifier.fillMaxWidth()
            ) { Text(stringResource(R.string.check_status)) }

            Spacer(Modifier.height(12.dp))

            TextButton(onClick = onAdminClick) {
                Text(stringResource(R.string.admin_login), color = PureWhite)
            }

            Row {
                TextButton(onClick = onTeacherClick) {
                    Text(stringResource(R.string.teacher_login), color = PureWhite)
                }
                TextButton(onClick = onStudentClick) {
                    Text(stringResource(R.string.student_login), color = PureWhite)
                }
            }
        }
    }
}
