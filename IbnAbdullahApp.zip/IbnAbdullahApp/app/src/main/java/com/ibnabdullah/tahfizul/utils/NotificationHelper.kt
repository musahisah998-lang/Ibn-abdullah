package com.ibnabdullah.tahfizul.utils

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.ibnabdullah.tahfizul.data.Applicant
import com.ibnabdullah.tahfizul.data.ApplicationStatus

/**
 * Local notifications for admission status changes. When Firebase Cloud
 * Messaging is wired up (see firebase/AdmissionMessagingService.kt), remote
 * pushes land through the same channel so the UX is consistent whether the
 * status change happened on this device or was synced from the admin.
 */
object NotificationHelper {
    private const val CHANNEL_ID = "admission_updates"

    fun createChannel(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Admission Updates",
                NotificationManager.IMPORTANCE_HIGH
            ).apply { description = "Notifications about your admission application status" }
            val manager = context.getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }
    }

    fun notifyStatusChange(context: Context, applicant: Applicant) {
        val message = when (applicant.status) {
            ApplicationStatus.APPROVED -> "Congratulations! Application ${applicant.applicationNumber} has been approved."
            ApplicationStatus.REJECTED -> "Application ${applicant.applicationNumber} was not successful this time."
            ApplicationStatus.SUBMITTED -> "Application ${applicant.applicationNumber} submitted successfully."
            ApplicationStatus.DRAFT -> return
        }

        val notification = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("Admission Update")
            .setContentText(message)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .build()

        NotificationManagerCompat.from(context)
            .notify(applicant.applicationNumber.hashCode(), notification)
    }
}
