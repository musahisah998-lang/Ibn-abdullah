package com.ibnabdullah.tahfizul.utils

import android.content.Context
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import android.os.Environment
import com.ibnabdullah.tahfizul.data.Applicant
import java.io.File
import java.io.FileOutputStream

/**
 * Renders a single applicant's details onto an A4-ish PDF page for printing
 * (covers requirement: "Print application details"). No external dependency
 * needed — uses android.graphics.pdf.PdfDocument.
 */
object PdfExporter {

    fun exportApplicant(context: Context, applicant: Applicant): File {
        val document = PdfDocument()
        val pageInfo = PdfDocument.PageInfo.Builder(595, 842, 1).create() // A4 at 72dpi
        val page = document.startPage(pageInfo)
        val canvas = page.canvas

        val titlePaint = Paint().apply { textSize = 16f; isFakeBoldText = true }
        val labelPaint = Paint().apply { textSize = 12f; isFakeBoldText = true }
        val valuePaint = Paint().apply { textSize = 12f }

        var y = 40f
        canvas.drawText("Ibn Abdullah Littahfizul Qur'an Wal Islamiyya", 40f, y, titlePaint)
        y += 20f
        canvas.drawText("Admission Application", 40f, y, labelPaint)
        y += 30f

        val fields = listOf(
            "Application Number" to applicant.applicationNumber,
            "Full Name" to applicant.fullName,
            "Date of Birth" to applicant.dateOfBirth,
            "Gender" to applicant.gender,
            "State of Origin" to applicant.stateOfOrigin,
            "Local Government" to applicant.localGovernment,
            "Home Address" to applicant.homeAddress,
            "Parent/Guardian" to applicant.parentGuardianName,
            "Parent Phone" to applicant.parentPhoneNumber,
            "Email" to (applicant.email ?: "-"),
            "Previous School" to applicant.previousSchool,
            "Class Applying For" to applicant.classApplyingFor,
            "Health Information" to applicant.healthInformation,
            "Status" to applicant.status.name
        )

        fields.forEach { (label, value) ->
            canvas.drawText("$label:", 40f, y, labelPaint)
            canvas.drawText(value, 220f, y, valuePaint)
            y += 22f
        }

        document.finishPage(page)

        val outDir = context.getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS)
            ?: context.filesDir
        val outFile = File(outDir, "${applicant.applicationNumber.replace("/", "_")}.pdf")
        FileOutputStream(outFile).use { document.writeTo(it) }
        document.close()
        return outFile
    }
}
