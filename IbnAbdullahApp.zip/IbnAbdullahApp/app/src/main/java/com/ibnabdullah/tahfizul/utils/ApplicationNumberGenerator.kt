package com.ibnabdullah.tahfizul.utils

/**
 * Produces unique, human-readable application numbers of the form:
 *   IALQ/<year>/<4-digit sequence>   e.g.  IALQ/2026/0001
 * The sequence is derived from how many applications already exist for that
 * year (see ApplicantRepository.saveApplication), so no separate counter
 * table is needed.
 */
object ApplicationNumberGenerator {
    fun generate(year: String, sequence: Int): String {
        val padded = sequence.toString().padStart(4, '0')
        return "IALQ/$year/$padded"
    }
}
