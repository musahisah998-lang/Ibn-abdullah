package com.ibnabdullah.tahfizul

import android.app.Application
import com.ibnabdullah.tahfizul.data.AppDatabase
import com.ibnabdullah.tahfizul.data.ApplicantRepository
import com.ibnabdullah.tahfizul.data.LessonRepository
import com.ibnabdullah.tahfizul.firebase.FirebaseSyncManager
import com.ibnabdullah.tahfizul.utils.NotificationHelper

class TahfizulApp : Application() {

    lateinit var repository: ApplicantRepository
        private set

    lateinit var lessonRepository: LessonRepository
        private set

    override fun onCreate() {
        super.onCreate()
        val db = AppDatabase.getInstance(this)
        // Firebase sync is optional — wrap in try/catch so the app still runs
        // fully offline if google-services.json hasn't been added yet.
        val sync = try { FirebaseSyncManager() } catch (e: Exception) { null }
        repository = ApplicantRepository(db.applicantDao(), db.adminDao(), sync)
        lessonRepository = LessonRepository(db.lessonDao(), db.teacherDao(), db.applicantDao())
        NotificationHelper.createChannel(this)
    }
}
