package com.ibnabdullah.tahfizul.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface ApplicantDao {

    @Insert
    suspend fun insert(applicant: Applicant): Long

    @Update
    suspend fun update(applicant: Applicant)

    @Query("SELECT * FROM applicants ORDER BY createdAt DESC")
    fun getAll(): Flow<List<Applicant>>

    @Query("SELECT * FROM applicants WHERE id = :id LIMIT 1")
    suspend fun getById(id: Long): Applicant?

    @Query("SELECT * FROM applicants WHERE applicationNumber = :appNumber LIMIT 1")
    suspend fun getByApplicationNumber(appNumber: String): Applicant?

    @Query("""
        SELECT * FROM applicants
        WHERE fullName LIKE '%' || :query || '%'
           OR applicationNumber LIKE '%' || :query || '%'
           OR parentPhoneNumber LIKE '%' || :query || '%'
        ORDER BY createdAt DESC
    """)
    fun search(query: String): Flow<List<Applicant>>

    @Query("SELECT * FROM applicants WHERE status = :status ORDER BY createdAt DESC")
    fun getByStatus(status: ApplicationStatus): Flow<List<Applicant>>

    @Query("SELECT * FROM applicants WHERE syncedToCloud = 0")
    suspend fun getUnsynced(): List<Applicant>

    @Query("SELECT COUNT(*) FROM applicants WHERE applicationNumber LIKE :yearPrefix || '%'")
    suspend fun countForYear(yearPrefix: String): Int

    @Delete
    suspend fun delete(applicant: Applicant)
}

@Dao
interface AdminDao {

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insert(admin: Admin): Long

    @Query("SELECT * FROM admins WHERE username = :username LIMIT 1")
    suspend fun getByUsername(username: String): Admin?

    @Query("SELECT COUNT(*) FROM admins")
    suspend fun count(): Int
}
