package com.ibnabdullah.tahfizul.data

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class UploaderRole { ADMIN, TEACHER }

/**
 * A lesson/study material uploaded by an admin or teacher, made visible to
 * approved students of the matching class. Files (PDF, images, docs) are
 * stored in app-private storage and referenced by URI, same pattern as
 * Applicant's photo/birth-certificate fields.
 */
@Entity(tableName = "lessons")
data class Lesson(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String = "",
    val description: String = "",
    val classOrSubject: String = "",   // must match Applicant.classApplyingFor to be visible
    val fileUri: String? = null,       // PDF, image, or any document
    val fileName: String = "",
    val uploadedByRole: UploaderRole = UploaderRole.ADMIN,
    val uploadedByName: String = "",
    val createdAt: Long = System.currentTimeMillis()
)
