package com.ibnabdullah.tahfizul.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.ibnabdullah.tahfizul.R
import com.ibnabdullah.tahfizul.data.Lesson
import com.ibnabdullah.tahfizul.data.UploaderRole

@Composable
fun UploadLessonScreen(
    uploaderName: String,
    uploaderRole: UploaderRole,
    onUpload: (Lesson) -> Unit,
    onBack: () -> Unit
) {
    var title by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var classOrSubject by remember { mutableStateOf("") }
    var fileUri by remember { mutableStateOf<Uri?>(null) }
    var fileName by remember { mutableStateOf("") }
    var uploaded by remember { mutableStateOf(false) }

    val filePicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        fileUri = uri
        fileName = uri?.lastPathSegment ?: ""
    }

    Scaffold(topBar = {
        TopAppBar(
            title = { Text(stringResource(R.string.upload_lesson)) },
            navigationIcon = {
                IconButton(onClick = onBack) {
                    Icon(androidx.compose.material.icons.Icons.Filled.ArrowBack, contentDescription = null)
                }
            }
        )
    }) { padding ->
        Column(modifier = Modifier.padding(padding).padding(16.dp)) {
            OutlinedTextField(title, { title = it }, label = { Text(stringResource(R.string.lesson_title)) }, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(classOrSubject, { classOrSubject = it }, label = { Text(stringResource(R.string.lesson_class)) }, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(description, { description = it }, label = { Text(stringResource(R.string.lesson_description)) }, modifier = Modifier.fillMaxWidth(), minLines = 3)
            Spacer(Modifier.height(8.dp))

            OutlinedButton(onClick = { filePicker.launch("*/*") }, modifier = Modifier.fillMaxWidth()) {
                Text(if (fileUri == null) stringResource(R.string.upload_lesson_file) else stringResource(R.string.document_selected))
            }

            Spacer(Modifier.height(24.dp))

            Button(
                onClick = {
                    onUpload(
                        Lesson(
                            title = title,
                            description = description,
                            classOrSubject = classOrSubject,
                            fileUri = fileUri?.toString(),
                            fileName = fileName,
                            uploadedByRole = uploaderRole,
                            uploadedByName = uploaderName
                        )
                    )
                    uploaded = true
                    title = ""; description = ""; classOrSubject = ""; fileUri = null; fileName = ""
                },
                enabled = title.isNotBlank() && classOrSubject.isNotBlank() && fileUri != null,
                modifier = Modifier.fillMaxWidth()
            ) { Text(stringResource(R.string.upload_lesson)) }

            if (uploaded) {
                Spacer(Modifier.height(12.dp))
                Text(stringResource(R.string.lesson_uploaded_success), color = MaterialTheme.colorScheme.primary)
            }
        }
    }
}
