package com.ibnabdullah.tahfizul.utils

import java.security.MessageDigest
import java.security.SecureRandom
import android.util.Base64

/**
 * Salted SHA-256 hashing for local admin credentials.
 * For production-grade auth, prefer Firebase Authentication instead —
 * see FirebaseSyncManager.signInAdmin() for the stub to swap this out.
 */
object PasswordHasher {

    fun generateSalt(): String {
        val bytes = ByteArray(16)
        SecureRandom().nextBytes(bytes)
        return Base64.encodeToString(bytes, Base64.NO_WRAP)
    }

    fun hash(password: String, salt: String): String {
        val digest = MessageDigest.getInstance("SHA-256")
        digest.update(Base64.decode(salt, Base64.NO_WRAP))
        val hashedBytes = digest.digest(password.toByteArray(Charsets.UTF_8))
        return Base64.encodeToString(hashedBytes, Base64.NO_WRAP)
    }
}
