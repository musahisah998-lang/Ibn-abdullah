package com.ibnabdullah.tahfizul

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.runtime.getValue
import androidx.compose.runtime.collectAsState
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.ibnabdullah.tahfizul.data.ApplicationStatus
import com.ibnabdullah.tahfizul.data.UploaderRole
import com.ibnabdullah.tahfizul.ui.screens.*
import com.ibnabdullah.tahfizul.ui.theme.IbnAbdullahTheme
import com.ibnabdullah.tahfizul.utils.NotificationHelper
import com.ibnabdullah.tahfizul.utils.PdfExporter
import com.ibnabdullah.tahfizul.utils.ExcelExporter
import com.ibnabdullah.tahfizul.viewmodel.ApplicantViewModel
import com.ibnabdullah.tahfizul.viewmodel.LessonViewModel

private object Routes {
    const val WELCOME = "welcome"
    const val APPLY = "apply"
    const val STATUS = "status"
    const val ADMIN_LOGIN = "admin_login"
    const val ADMIN_DASHBOARD = "admin_dashboard"
    const val TEACHER_LOGIN = "teacher_login"
    const val STUDENT_LOGIN = "student_login"
    const val UPLOAD_LESSON_ADMIN = "upload_lesson_admin"
    const val UPLOAD_LESSON_TEACHER = "upload_lesson_teacher"
    const val LESSONS_STUDENT = "lessons_student"
}

class MainActivity : ComponentActivity() {

    private val viewModel: ApplicantViewModel by viewModels {
        ApplicantViewModel.Factory((application as TahfizulApp).repository)
    }

    private val lessonViewModel: LessonViewModel by viewModels {
        LessonViewModel.Factory((application as TahfizulApp).lessonRepository)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            IbnAbdullahTheme {
                val navController = rememberNavController()
                AppNavHost(navController, viewModel, lessonViewModel)
            }
        }
    }
}

@androidx.compose.runtime.Composable
private fun AppNavHost(
    navController: NavHostController,
    viewModel: ApplicantViewModel,
    lessonViewModel: LessonViewModel
) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val applicants by viewModel.applicants.collectAsState()
    val statusResult by viewModel.statusCheckResult.collectAsState()
    val lessons by lessonViewModel.lessons.collectAsState()
    val loggedInTeacher by lessonViewModel.loggedInTeacher.collectAsState()

    NavHost(navController = navController, startDestination = Routes.WELCOME) {

        composable(Routes.WELCOME) {
            WelcomeScreen(
                onApplyClick = { navController.navigate(Routes.APPLY) },
                onCheckStatusClick = { navController.navigate(Routes.STATUS) },
                onAdminClick = { navController.navigate(Routes.ADMIN_LOGIN) },
                onTeacherClick = { navController.navigate(Routes.TEACHER_LOGIN) },
                onStudentClick = { navController.navigate(Routes.STUDENT_LOGIN) }
            )
        }

        composable(Routes.APPLY) {
            ApplicationFormScreen(
                onSaveDraft = { viewModel.saveDraft(it) },
                onSubmit = {
                    viewModel.submitApplication(it)
                    navController.popBackStack(Routes.WELCOME, inclusive = false)
                },
                onBack = { navController.popBackStack() }
            )
        }

        composable(Routes.STATUS) {
            StatusCheckerScreen(
                result = statusResult,
                onCheck = { viewModel.checkStatus(it) },
                onBack = { navController.popBackStack() }
            )
        }

        composable(Routes.ADMIN_LOGIN) {
            AdminLoginScreen(
                onLogin = { u, p, cb -> viewModel.login(u, p, cb) },
                onLoginSuccess = { navController.navigate(Routes.ADMIN_DASHBOARD) },
                onBack = { navController.popBackStack() }
            )
        }

        composable(Routes.ADMIN_DASHBOARD) {
            AdminDashboardScreen(
                applicants = applicants,
                onSearch = { viewModel.search(it) },
                onFilter = { status ->
                    if (status == null) viewModel.search("") else viewModel.filterByStatus(status)
                },
                onApprove = {
                    viewModel.approve(it)
                    NotificationHelper.notifyStatusChange(context, it.copy(status = ApplicationStatus.APPROVED))
                },
                onReject = { applicant, reason ->
                    viewModel.reject(applicant, reason)
                    NotificationHelper.notifyStatusChange(context, applicant.copy(status = ApplicationStatus.REJECTED))
                },
                onPrint = { PdfExporter.exportApplicant(context, it) },
                onExportPdfAll = { applicants.forEach { PdfExporter.exportApplicant(context, it) } },
                onExportExcel = { ExcelExporter.exportAll(context, applicants) },
                onUploadLesson = { navController.navigate(Routes.UPLOAD_LESSON_ADMIN) },
                onLogout = {
                    viewModel.logout()
                    navController.popBackStack(Routes.WELCOME, inclusive = false)
                }
            )
        }

        composable(Routes.UPLOAD_LESSON_ADMIN) {
            UploadLessonScreen(
                uploaderName = "School Administrator",
                uploaderRole = UploaderRole.ADMIN,
                onUpload = { lessonViewModel.uploadLesson(it) },
                onBack = { navController.popBackStack() }
            )
        }

        composable(Routes.TEACHER_LOGIN) {
            TeacherLoginScreen(
                onLogin = { u, p, cb -> lessonViewModel.teacherLogin(u, p, cb) },
                onLoginSuccess = { navController.navigate(Routes.UPLOAD_LESSON_TEACHER) },
                onBack = { navController.popBackStack() }
            )
        }

        composable(Routes.UPLOAD_LESSON_TEACHER) {
            UploadLessonScreen(
                uploaderName = loggedInTeacher?.fullName ?: "Teacher",
                uploaderRole = UploaderRole.TEACHER,
                onUpload = { lessonViewModel.uploadLesson(it) },
                onBack = {
                    lessonViewModel.teacherLogout()
                    navController.popBackStack(Routes.WELCOME, inclusive = false)
                }
            )
        }

        composable(Routes.STUDENT_LOGIN) {
            StudentLoginScreen(
                onLogin = { appNum, phone, cb -> lessonViewModel.studentLogin(appNum, phone, cb) },
                onLoginSuccess = { navController.navigate(Routes.LESSONS_STUDENT) },
                onBack = { navController.popBackStack() }
            )
        }

        composable(Routes.LESSONS_STUDENT) {
            LessonListScreen(
                lessons = lessons,
                onOpenLesson = { lesson ->
                    lesson.fileUri?.let { uriString ->
                        try {
                            val uri = android.net.Uri.parse(uriString)
                            val intent = android.content.Intent(android.content.Intent.ACTION_VIEW).apply {
                                setDataAndType(uri, context.contentResolver.getType(uri) ?: "*/*")
                                addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
                            }
                            context.startActivity(intent)
                        } catch (e: Exception) {
                            android.widget.Toast.makeText(context, "Unable to open file", android.widget.Toast.LENGTH_SHORT).show()
                        }
                    }
                },
                onBack = { navController.popBackStack() },
                onLogout = {
                    lessonViewModel.studentLogout()
                    navController.popBackStack(Routes.WELCOME, inclusive = false)
                }
            )
        }
    }
}
