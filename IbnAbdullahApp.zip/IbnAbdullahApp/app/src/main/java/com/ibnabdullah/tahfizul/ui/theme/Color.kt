package com.ibnabdullah.tahfizul.ui.theme

import androidx.compose.ui.graphics.Color

// Islamic green & white palette
val IslamicGreen = Color(0xFF0B6E4F)
val IslamicGreenDark = Color(0xFF07472F)
val IslamicGreenLight = Color(0xFF4CA37B)
val GoldAccent = Color(0xFFC9A227)
val OffWhite = Color(0xFFFAFAF7)
val PureWhite = Color(0xFFFFFFFF)
val TextDark = Color(0xFF1B1B1B)
val ErrorRed = Color(0xFFB3261E)
