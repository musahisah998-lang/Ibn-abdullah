package com.ibnabdullah.tahfizul.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.ibnabdullah.tahfizul.R
import com.ibnabdullah.tahfizul.data.Lesson

@Composable
fun LessonListScreen(
    lessons: List<Lesson>,
    onOpenLesson: (Lesson) -> Unit,
    onBack: () -> Unit,
    onLogout: (() -> Unit)? = null
) {
    Scaffold(topBar = {
        TopAppBar(
            title = { Text(stringResource(R.string.lessons)) },
            navigationIcon = {
                IconButton(onClick = onBack) {
                    Icon(androidx.compose.material.icons.Icons.Filled.ArrowBack, contentDescription = null)
                }
            },
            actions = {
                onLogout?.let { TextButton(onClick = it) { Text(stringResource(R.string.logout)) } }
            }
        )
    }) { padding ->
        if (lessons.isEmpty()) {
            Box(modifier = Modifier.padding(padding).fillMaxSize(), contentAlignment = androidx.compose.ui.Alignment.Center) {
                Text(stringResource(R.string.no_lessons_yet))
            }
        } else {
            LazyColumn(modifier = Modifier.padding(padding).padding(12.dp)) {
                items(lessons) { lesson ->
                    ElevatedCard(
                        modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp)
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text(lesson.title, style = MaterialTheme.typography.titleMedium)
                            Text(lesson.classOrSubject, style = MaterialTheme.typography.bodyMedium)
                            if (lesson.description.isNotBlank()) {
                                Spacer(Modifier.height(4.dp))
                                Text(lesson.description, style = MaterialTheme.typography.bodyMedium)
                            }
                            Spacer(Modifier.height(8.dp))
                            TextButton(onClick = { onOpenLesson(lesson) }) {
                                Text(stringResource(R.string.open_file))
                            }
                        }
                    }
                }
            }
        }
    }
}
