package com.ibnabdullah.tahfizul.data

import com.ibnabdullah.tahfizul.utils.PasswordHasher
import kotlinx.coroutines.flow.Flow

/**
 * Handles lesson uploads/viewing plus the two extra login types this feature
 * introduces: Teacher (upload access) and Student/Parent (view-only access,
 * reusing their existing application data instead of a separate signup).
 */
class LessonRepository(
    private val lessonDao: LessonDao,
    private val teacherDao: TeacherDao,
    private val applicantDao: ApplicantDao
) {
    fun getAllLessons(): Flow<List<Lesson>> = lessonDao.getAll()

    fun getLessonsForClass(classOrSubject: String): Flow<List<Lesson>> =
        lessonDao.getByClass(classOrSubject)

    suspend fun uploadLesson(lesson: Lesson) = lessonDao.insert(lesson)

    suspend fun deleteLesson(lesson: Lesson) = lessonDao.delete(lesson)

    suspend fun registerTeacher(username: String, password: String, fullName: String, subjectOrClass: String): Boolean {
        val salt = PasswordHasher.generateSalt()
        val hash = PasswordHasher.hash(password, salt)
        val id = teacherDao.insert(Teacher(username = username, passwordHash = hash, salt = salt, fullName = fullName, subjectOrClass = subjectOrClass))
        return id != -1L
    }

    suspend fun verifyTeacherLogin(username: String, password: String): Teacher? {
        val teacher = teacherDao.getByUsername(username) ?: return null
        val hash = PasswordHasher.hash(password, teacher.salt)
        return if (hash == teacher.passwordHash) teacher else null
    }

    /**
     * "Login" for students/parents: they already have an Application Number
     * and phone number from admission — no separate signup needed. Access is
     * only granted once their application status is APPROVED, i.e. they are
     * an enrolled student.
     */
    suspend fun verifyStudentAccess(applicationNumber: String, parentPhoneNumber: String): Applicant? {
        val applicant = applicantDao.getByApplicationNumber(applicationNumber) ?: return null
        return if (
            applicant.parentPhoneNumber.trim() == parentPhoneNumber.trim() &&
            applicant.status == ApplicationStatus.APPROVED
        ) applicant else null
    }
}
