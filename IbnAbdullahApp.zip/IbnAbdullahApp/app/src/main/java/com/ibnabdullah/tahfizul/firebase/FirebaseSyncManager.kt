package com.ibnabdullah.tahfizul.firebase

import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.ibnabdullah.tahfizul.data.Applicant
import kotlinx.coroutines.tasks.await

/**
 * Optional online sync layer. The app is fully functional offline via Room;
 * this class is only consulted when a network connection is available
 * (checked by the caller via ConnectivityManager before invoking).
 *
 * Collection layout in Firestore:
 *   applicants/{applicationNumber}  -> mirrors the Room row
 */
class FirebaseSyncManager(
    private val firestore: FirebaseFirestore = FirebaseFirestore.getInstance(),
    private val auth: FirebaseAuth = FirebaseAuth.getInstance()
) {
    private val collection = firestore.collection("applicants")

    /** Marks a record dirty for the next sync pass; a no-op stub here since
     * the repository already tracks `syncedToCloud = false` in Room. Kept as
     * an extension point (e.g. to trigger a WorkManager job immediately). */
    fun queueForSync(applicant: Applicant) { /* hook for WorkManager, if desired */ }

    /** Pushes one applicant record to Firestore. Returns true on success. */
    suspend fun pushApplicant(applicant: Applicant): Boolean = try {
        collection.document(applicant.applicationNumber).set(applicant).await()
        true
    } catch (e: Exception) {
        false
    }

    /** Pulls the latest copy of one applicant from Firestore, if present. */
    suspend fun fetchApplicant(applicationNumber: String): Applicant? = try {
        collection.document(applicationNumber).get().await()
            .toObject(Applicant::class.java)
    } catch (e: Exception) {
        null
    }

    /**
     * Stub for swapping local admin auth for real Firebase Authentication.
     * Replace ApplicantRepository.verifyAdminLogin() with a call to this once
     * admin accounts are migrated to Firebase Auth (email/password).
     */
    suspend fun signInAdmin(email: String, password: String): Boolean = try {
        auth.signInWithEmailAndPassword(email, password).await()
        true
    } catch (e: Exception) {
        false
    }
}
