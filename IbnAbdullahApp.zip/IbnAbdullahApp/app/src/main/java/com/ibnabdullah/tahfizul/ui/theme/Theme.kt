package com.ibnabdullah.tahfizul.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable

private val LightColors = lightColorScheme(
    primary = IslamicGreen,
    onPrimary = PureWhite,
    primaryContainer = IslamicGreenLight,
    onPrimaryContainer = PureWhite,
    secondary = GoldAccent,
    onSecondary = TextDark,
    background = OffWhite,
    onBackground = TextDark,
    surface = PureWhite,
    onSurface = TextDark,
    error = ErrorRed
)

private val DarkColors = darkColorScheme(
    primary = IslamicGreenLight,
    onPrimary = TextDark,
    primaryContainer = IslamicGreenDark,
    onPrimaryContainer = PureWhite,
    secondary = GoldAccent,
    background = Color0F,
    onBackground = PureWhite,
    surface = Color1A,
    onSurface = PureWhite,
    error = ErrorRed
)

// Small dark-mode surface colors kept local to avoid extra file
private val Color0F = androidx.compose.ui.graphics.Color(0xFF0F1210)
private val Color1A = androidx.compose.ui.graphics.Color(0xFF1A1F1C)

@Composable
fun IbnAbdullahTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colors = if (darkTheme) DarkColors else LightColors
    MaterialTheme(
        colorScheme = colors,
        typography = AppTypography,
        content = content
    )
}
