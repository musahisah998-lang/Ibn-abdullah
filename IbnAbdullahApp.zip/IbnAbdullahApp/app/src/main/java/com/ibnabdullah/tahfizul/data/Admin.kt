package com.ibnabdullah.tahfizul.data

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Local admin account. Password is never stored in plain text — see
 * [com.ibnabdullah.tahfizul.utils.PasswordHasher] for the salted-hash routine
 * used both when seeding the default account and when verifying login.
 */
@Entity(tableName = "admins")
data class Admin(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val username: String,
    val passwordHash: String,
    val salt: String,
    val fullName: String = "",
    val createdAt: Long = System.currentTimeMillis()
)
