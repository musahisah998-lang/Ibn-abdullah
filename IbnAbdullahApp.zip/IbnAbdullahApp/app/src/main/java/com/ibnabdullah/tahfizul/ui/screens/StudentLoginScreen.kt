package com.ibnabdullah.tahfizul.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.ibnabdullah.tahfizul.R

@Composable
fun StudentLoginScreen(
    onLogin: (applicationNumber: String, phone: String, onResult: (Boolean) -> Unit) -> Unit,
    onLoginSuccess: () -> Unit,
    onBack: () -> Unit
) {
    var appNumber by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }

    Scaffold(topBar = {
        TopAppBar(
            title = { Text(stringResource(R.string.student_login)) },
            navigationIcon = {
                IconButton(onClick = onBack) {
                    Icon(androidx.compose.material.icons.Icons.Filled.ArrowBack, contentDescription = null)
                }
            }
        )
    }) { padding ->
        Column(
            modifier = Modifier.padding(padding).padding(24.dp).fillMaxSize(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text(stringResource(R.string.student_login_hint), textAlign = androidx.compose.ui.text.style.TextAlign.Center)
            Spacer(Modifier.height(16.dp))

            OutlinedTextField(
                appNumber, { appNumber = it },
                label = { Text(stringResource(R.string.application_number)) },
                placeholder = { Text("IALQ/2026/0001") },
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(12.dp))
            OutlinedTextField(
                phone, { phone = it },
                label = { Text(stringResource(R.string.guardian_phone)) },
                modifier = Modifier.fillMaxWidth()
            )
            if (error != null) {
                Spacer(Modifier.height(8.dp))
                Text(error!!, color = MaterialTheme.colorScheme.error)
            }
            Spacer(Modifier.height(20.dp))
            Button(
                onClick = {
                    onLogin(appNumber.trim(), phone.trim()) { success ->
                        if (success) onLoginSuccess() else error = "No approved student found with these details"
                    }
                },
                enabled = appNumber.isNotBlank() && phone.isNotBlank(),
                modifier = Modifier.fillMaxWidth()
            ) { Text(stringResource(R.string.sign_in)) }
        }
    }
}
