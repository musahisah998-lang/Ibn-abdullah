package com.ibnabdullah.tahfizul.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.ibnabdullah.tahfizul.data.Applicant
import com.ibnabdullah.tahfizul.data.Lesson
import com.ibnabdullah.tahfizul.data.LessonRepository
import com.ibnabdullah.tahfizul.data.Teacher
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

class LessonViewModel(private val repository: LessonRepository) : ViewModel() {

    private val _lessons = MutableStateFlow<List<Lesson>>(emptyList())
    val lessons: StateFlow<List<Lesson>> = _lessons

    private val _loggedInTeacher = MutableStateFlow<Teacher?>(null)
    val loggedInTeacher: StateFlow<Teacher?> = _loggedInTeacher

    private val _loggedInStudent = MutableStateFlow<Applicant?>(null)
    val loggedInStudent: StateFlow<Applicant?> = _loggedInStudent

    fun loadAllLessons() {
        viewModelScope.launch { repository.getAllLessons().collectLatest { _lessons.value = it } }
    }

    fun loadLessonsForClass(classOrSubject: String) {
        viewModelScope.launch { repository.getLessonsForClass(classOrSubject).collectLatest { _lessons.value = it } }
    }

    fun uploadLesson(lesson: Lesson) {
        viewModelScope.launch { repository.uploadLesson(lesson) }
    }

    fun deleteLesson(lesson: Lesson) {
        viewModelScope.launch { repository.deleteLesson(lesson) }
    }

    fun registerTeacher(username: String, password: String, fullName: String, subjectOrClass: String, onResult: (Boolean) -> Unit) {
        viewModelScope.launch { onResult(repository.registerTeacher(username, password, fullName, subjectOrClass)) }
    }

    fun teacherLogin(username: String, password: String, onResult: (Boolean) -> Unit) {
        viewModelScope.launch {
            val teacher = repository.verifyTeacherLogin(username, password)
            _loggedInTeacher.value = teacher
            onResult(teacher != null)
        }
    }

    fun studentLogin(applicationNumber: String, parentPhoneNumber: String, onResult: (Boolean) -> Unit) {
        viewModelScope.launch {
            val applicant = repository.verifyStudentAccess(applicationNumber, parentPhoneNumber)
            _loggedInStudent.value = applicant
            if (applicant != null) loadLessonsForClass(applicant.classApplyingFor)
            onResult(applicant != null)
        }
    }

    fun teacherLogout() { _loggedInTeacher.value = null }
    fun studentLogout() { _loggedInStudent.value = null }

    class Factory(private val repository: LessonRepository) : ViewModelProvider.Factory {
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            @Suppress("UNCHECKED_CAST")
            return LessonViewModel(repository) as T
        }
    }
}
