package com.ibnabdullah.tahfizul.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverter
import androidx.room.TypeConverters
import androidx.sqlite.db.SupportSQLiteDatabase
import com.ibnabdullah.tahfizul.utils.PasswordHasher
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class Converters {
    @TypeConverter
    fun fromStatus(status: ApplicationStatus): String = status.name

    @TypeConverter
    fun toStatus(value: String): ApplicationStatus = ApplicationStatus.valueOf(value)

    @TypeConverter
    fun fromRole(role: UploaderRole): String = role.name

    @TypeConverter
    fun toRole(value: String): UploaderRole = UploaderRole.valueOf(value)
}

@Database(
    entities = [Applicant::class, Admin::class, Teacher::class, Lesson::class],
    version = 2,
    exportSchema = false
)
@TypeConverters(Converters::class)
abstract class AppDatabase : RoomDatabase() {

    abstract fun applicantDao(): ApplicantDao
    abstract fun adminDao(): AdminDao
    abstract fun teacherDao(): TeacherDao
    abstract fun lessonDao(): LessonDao

    companion object {
        @Volatile private var INSTANCE: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase =
            INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "ibn_abdullah_admissions.db"
                )
                    // Schema changed (added teachers/lessons tables) after the app
                    // was already shipped once — fallback wipes local data on that
                    // upgrade instead of crashing. Fine pre-launch; replace with a
                    // real Migration before this app has real users' data on device.
                    .fallbackToDestructiveMigration()
                    .addCallback(object : Callback() {
                        override fun onCreate(db: SupportSQLiteDatabase) {
                            super.onCreate(db)
                            // Seed a default admin account on first run.
                            // ⚠️ Change this password immediately in production.
                            CoroutineScope(Dispatchers.IO).launch {
                                val database = getInstance(context)
                                if (database.adminDao().count() == 0) {
                                    val salt = PasswordHasher.generateSalt()
                                    val hash = PasswordHasher.hash("Admin@12345", salt)
                                    database.adminDao().insert(
                                        Admin(
                                            username = "admin",
                                            passwordHash = hash,
                                            salt = salt,
                                            fullName = "School Administrator"
                                        )
                                    )
                                }
                            }
                        }
                    })
                    .build()
                    .also { INSTANCE = it }
            }
    }
}
