package com.ibnabdullah.tahfizul.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.ibnabdullah.tahfizul.data.Admin
import com.ibnabdullah.tahfizul.data.Applicant
import com.ibnabdullah.tahfizul.data.ApplicantRepository
import com.ibnabdullah.tahfizul.data.ApplicationStatus
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

class ApplicantViewModel(private val repository: ApplicantRepository) : ViewModel() {

    private val _applicants = MutableStateFlow<List<Applicant>>(emptyList())
    val applicants: StateFlow<List<Applicant>> = _applicants

    private val _loggedInAdmin = MutableStateFlow<Admin?>(null)
    val loggedInAdmin: StateFlow<Admin?> = _loggedInAdmin

    private val _lastSubmitted = MutableStateFlow<Applicant?>(null)
    val lastSubmitted: StateFlow<Applicant?> = _lastSubmitted

    private val _statusCheckResult = MutableStateFlow<Applicant?>(null)
    val statusCheckResult: StateFlow<Applicant?> = _statusCheckResult

    init {
        viewModelScope.launch {
            repository.getAllApplicants().collectLatest { _applicants.value = it }
        }
    }

    fun submitApplication(applicant: Applicant) {
        viewModelScope.launch {
            val saved = repository.submitApplication(applicant)
            _lastSubmitted.value = saved
        }
    }

    fun saveDraft(applicant: Applicant) {
        viewModelScope.launch { repository.saveApplication(applicant) }
    }

    fun search(query: String) {
        viewModelScope.launch {
            repository.searchApplicants(query).collectLatest { _applicants.value = it }
        }
    }

    fun filterByStatus(status: ApplicationStatus) {
        viewModelScope.launch {
            repository.getApplicantsByStatus(status).collectLatest { _applicants.value = it }
        }
    }

    fun approve(applicant: Applicant) {
        viewModelScope.launch { repository.approve(applicant) }
    }

    fun reject(applicant: Applicant, reason: String) {
        viewModelScope.launch { repository.reject(applicant, reason) }
    }

    fun checkStatus(applicationNumber: String) {
        viewModelScope.launch {
            _statusCheckResult.value = repository.getByApplicationNumber(applicationNumber)
        }
    }

    fun login(username: String, password: String, onResult: (Boolean) -> Unit) {
        viewModelScope.launch {
            val admin = repository.verifyAdminLogin(username, password)
            _loggedInAdmin.value = admin
            onResult(admin != null)
        }
    }

    fun logout() { _loggedInAdmin.value = null }

    fun syncNow() {
        viewModelScope.launch { repository.syncPendingToCloud() }
    }

    class Factory(private val repository: ApplicantRepository) : ViewModelProvider.Factory {
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            @Suppress("UNCHECKED_CAST")
            return ApplicantViewModel(repository) as T
        }
    }
}
