package com.ibnabdullah.tahfizul.data

import com.ibnabdullah.tahfizul.firebase.FirebaseSyncManager
import com.ibnabdullah.tahfizul.utils.ApplicationNumberGenerator
import kotlinx.coroutines.flow.Flow

/**
 * Single source of truth for applicant data. UI/ViewModel never talks to Room
 * or Firebase directly — everything routes through here so the app stays
 * offline-first: writes always land in Room immediately, then get queued for
 * Firebase sync when connectivity allows.
 */
class ApplicantRepository(
    private val dao: ApplicantDao,
    private val adminDao: AdminDao,
    private val cloudSync: FirebaseSyncManager? = null
) {
    fun getAllApplicants(): Flow<List<Applicant>> = dao.getAll()

    fun searchApplicants(query: String): Flow<List<Applicant>> = dao.search(query)

    fun getApplicantsByStatus(status: ApplicationStatus): Flow<List<Applicant>> =
        dao.getByStatus(status)

    suspend fun getByApplicationNumber(appNumber: String): Applicant? =
        dao.getByApplicationNumber(appNumber)

    /** Saves a draft or new application, generating an application number if missing. */
    suspend fun saveApplication(applicant: Applicant): Applicant {
        val withNumber = if (applicant.applicationNumber.isBlank()) {
            val year = java.text.SimpleDateFormat("yyyy", java.util.Locale.US)
                .format(java.util.Date())
            val prefix = "IALQ/$year/"
            val countThisYear = dao.countForYear(prefix)
            applicant.copy(
                applicationNumber = ApplicationNumberGenerator.generate(year, countThisYear + 1)
            )
        } else applicant

        val toSave = withNumber.copy(updatedAt = System.currentTimeMillis())
        if (toSave.id == 0L) {
            val newId = dao.insert(toSave)
            val saved = toSave.copy(id = newId)
            cloudSync?.queueForSync(saved)
            return saved
        } else {
            dao.update(toSave)
            cloudSync?.queueForSync(toSave)
            return toSave
        }
    }

    suspend fun submitApplication(applicant: Applicant): Applicant =
        saveApplication(applicant.copy(status = ApplicationStatus.SUBMITTED))

    suspend fun approve(applicant: Applicant) {
        val updated = applicant.copy(
            status = ApplicationStatus.APPROVED,
            rejectionReason = null,
            updatedAt = System.currentTimeMillis(),
            syncedToCloud = false
        )
        dao.update(updated)
        cloudSync?.queueForSync(updated)
    }

    suspend fun reject(applicant: Applicant, reason: String) {
        val updated = applicant.copy(
            status = ApplicationStatus.REJECTED,
            rejectionReason = reason,
            updatedAt = System.currentTimeMillis(),
            syncedToCloud = false
        )
        dao.update(updated)
        cloudSync?.queueForSync(updated)
    }

    suspend fun verifyAdminLogin(username: String, password: String): Admin? {
        val admin = adminDao.getByUsername(username) ?: return null
        val hash = com.ibnabdullah.tahfizul.utils.PasswordHasher.hash(password, admin.salt)
        return if (hash == admin.passwordHash) admin else null
    }

    suspend fun syncPendingToCloud() {
        cloudSync?.let { sync ->
            val unsynced = dao.getUnsynced()
            unsynced.forEach { applicant ->
                if (sync.pushApplicant(applicant)) {
                    dao.update(applicant.copy(syncedToCloud = true))
                }
            }
        }
    }
}
