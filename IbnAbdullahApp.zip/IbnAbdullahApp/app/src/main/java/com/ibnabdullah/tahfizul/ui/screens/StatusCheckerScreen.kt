package com.ibnabdullah.tahfizul.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.ibnabdullah.tahfizul.R
import com.ibnabdullah.tahfizul.data.Applicant
import com.ibnabdullah.tahfizul.data.ApplicationStatus

@Composable
fun StatusCheckerScreen(
    result: Applicant?,
    onCheck: (String) -> Unit,
    onBack: () -> Unit
) {
    var appNumber by remember { mutableStateOf("") }

    Scaffold(topBar = {
        TopAppBar(
            title = { Text(stringResource(R.string.check_status)) },
            navigationIcon = {
                IconButton(onClick = onBack) {
                    Icon(androidx.compose.material.icons.Icons.Filled.ArrowBack, contentDescription = null)
                }
            }
        )
    }) { padding ->
        Column(modifier = Modifier.padding(padding).padding(20.dp)) {
            OutlinedTextField(
                value = appNumber,
                onValueChange = { appNumber = it },
                label = { Text(stringResource(R.string.application_number)) },
                placeholder = { Text("IALQ/2026/0001") },
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(12.dp))
            Button(onClick = { onCheck(appNumber.trim()) }, modifier = Modifier.fillMaxWidth()) {
                Text(stringResource(R.string.check_status))
            }

            Spacer(Modifier.height(24.dp))

            when {
                result == null && appNumber.isBlank() -> {}
                result == null -> Text(stringResource(R.string.no_application_found))
                else -> {
                    val statusText = when (result.status) {
                        ApplicationStatus.APPROVED -> stringResource(R.string.status_approved)
                        ApplicationStatus.REJECTED -> stringResource(R.string.status_rejected)
                        ApplicationStatus.SUBMITTED -> stringResource(R.string.status_submitted)
                        ApplicationStatus.DRAFT -> stringResource(R.string.status_draft)
                    }
                    ElevatedCard(modifier = Modifier.fillMaxWidth()) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text(result.fullName, style = MaterialTheme.typography.titleLarge)
                            Text(result.applicationNumber, style = MaterialTheme.typography.bodyMedium)
                            Spacer(Modifier.height(8.dp))
                            Text(statusText, style = MaterialTheme.typography.titleMedium)
                            if (result.status == ApplicationStatus.REJECTED && !result.rejectionReason.isNullOrBlank()) {
                                Spacer(Modifier.height(4.dp))
                                Text("Reason: ${result.rejectionReason}")
                            }
                        }
                    }
                }
            }
        }
    }
}
