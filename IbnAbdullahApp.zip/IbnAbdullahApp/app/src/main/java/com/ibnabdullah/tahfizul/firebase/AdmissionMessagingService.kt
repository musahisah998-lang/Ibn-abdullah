package com.ibnabdullah.tahfizul.firebase

import android.app.NotificationManager
import android.content.Context
import androidx.core.app.NotificationCompat
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage

/**
 * Receives remote push notifications (e.g. admin approves/rejects an
 * application from the web console) and surfaces them locally. Requires
 * google-services.json to be added and the plugin enabled — see README.
 */
class AdmissionMessagingService : FirebaseMessagingService() {

    override fun onMessageReceived(message: RemoteMessage) {
        val title = message.notification?.title ?: "Admission Update"
        val body = message.notification?.body ?: return

        val notification = NotificationCompat.Builder(this, "admission_updates")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle(title)
            .setContentText(body)
            .setAutoCancel(true)
            .build()

        val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        manager.notify(System.currentTimeMillis().toInt(), notification)
    }

    override fun onNewToken(token: String) {
        // TODO: send token to your backend / Firestore user doc if you want
        // targeted per-applicant push notifications.
    }
}
